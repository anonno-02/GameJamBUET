gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDGreenBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDGreenBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueWallObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueWallObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueWall2Objects1= [];
gdjs.Untitled_32sceneCode.GDBlueWall2Objects2= [];
gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDRedWallObjects1= [];
gdjs.Untitled_32sceneCode.GDRedWallObjects2= [];
gdjs.Untitled_32sceneCode.GDRedWall2Objects1= [];
gdjs.Untitled_32sceneCode.GDRedWall2Objects2= [];
gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDRedWallBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDBlackWallObjects1= [];
gdjs.Untitled_32sceneCode.GDBlackWallObjects2= [];
gdjs.Untitled_32sceneCode.GDBlackWall2Objects1= [];
gdjs.Untitled_32sceneCode.GDBlackWall2Objects2= [];
gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDCursorObjects1= [];
gdjs.Untitled_32sceneCode.GDCursorObjects2= [];
gdjs.Untitled_32sceneCode.GDCrossHairObjects1= [];
gdjs.Untitled_32sceneCode.GDCrossHairObjects2= [];
gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1= [];
gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects2= [];
gdjs.Untitled_32sceneCode.GDCalicoObjects1= [];
gdjs.Untitled_32sceneCode.GDCalicoObjects2= [];
gdjs.Untitled_32sceneCode.GDBulletsObjects1= [];
gdjs.Untitled_32sceneCode.GDBulletsObjects2= [];
gdjs.Untitled_32sceneCode.GDBulletsUsedObjects1= [];
gdjs.Untitled_32sceneCode.GDBulletsUsedObjects2= [];
gdjs.Untitled_32sceneCode.GDTimeObjects1= [];
gdjs.Untitled_32sceneCode.GDTimeObjects2= [];
gdjs.Untitled_32sceneCode.GDTimeUsedObjects1= [];
gdjs.Untitled_32sceneCode.GDTimeUsedObjects2= [];
gdjs.Untitled_32sceneCode.GDWinObjects1= [];
gdjs.Untitled_32sceneCode.GDWinObjects2= [];
gdjs.Untitled_32sceneCode.GDLoseObjects1= [];
gdjs.Untitled_32sceneCode.GDLoseObjects2= [];


gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallObjects1Objects = Hashtable.newFrom({"BlueWall": gdjs.Untitled_32sceneCode.GDBlueWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWall2Objects1Objects = Hashtable.newFrom({"BlueWall2": gdjs.Untitled_32sceneCode.GDBlueWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWallObjects = Hashtable.newFrom({"BlackWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWall2Objects = Hashtable.newFrom({"BlackWall2": []});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Untitled_32sceneCode.GDRedWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Untitled_32sceneCode.GDRedWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallBulletObjects1Objects = Hashtable.newFrom({"BlackWallBullet": gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallBulletObjects1Objects = Hashtable.newFrom({"BlackWallBullet": gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallBulletObjects1Objects = Hashtable.newFrom({"BlackWallBullet": gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallObjects1Objects = Hashtable.newFrom({"BlueWall": gdjs.Untitled_32sceneCode.GDBlueWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallObjects1Objects = Hashtable.newFrom({"BlueWall": gdjs.Untitled_32sceneCode.GDBlueWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWall2Objects1Objects = Hashtable.newFrom({"BlueWall2": gdjs.Untitled_32sceneCode.GDBlueWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWall2Objects1Objects = Hashtable.newFrom({"BlueWall2": gdjs.Untitled_32sceneCode.GDBlueWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Untitled_32sceneCode.GDRedWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Untitled_32sceneCode.GDRedWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Untitled_32sceneCode.GDRedWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Untitled_32sceneCode.GDRedWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Untitled_32sceneCode.GDRedWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Untitled_32sceneCode.GDRedWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Untitled_32sceneCode.GDRedWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Untitled_32sceneCode.GDRedWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Untitled_32sceneCode.GDBlackWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Untitled_32sceneCode.GDBlackWall2Objects1});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWallObjects = Hashtable.newFrom({"BlackWall": []});
gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWall2Objects = Hashtable.newFrom({"BlackWall2": []});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Lose"), gdjs.Untitled_32sceneCode.GDLoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Untitled_32sceneCode.GDWinObjects1);
{gdjs.evtsExt__WithThreeJS__Create3DScene.func(runtimeScene, 50, "153;150;189", "", "", 1, 1000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWinObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLoseObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLoseObjects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Untitled_32sceneCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Time"), gdjs.Untitled_32sceneCode.GDTimeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTimeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTimeObjects1[i].setString(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer"))));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].setAngle((( gdjs.Untitled_32sceneCode.GDCursorObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCursorObjects1[0].getPointX("")) - 90);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].getAngle()), 150, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].getAngle()) - 90, 150, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].getAngle()) + 180, 150, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].getAngle()) + 90, 150, 0);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWallObjects) >= 24;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWall2Objects) >= 24;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13441204);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullets"), gdjs.Untitled_32sceneCode.GDBulletsObjects1);
gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, (( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].setZOrder(25);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].addPolarForce((( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getAngle()), 450, 1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletsObjects1[i].setString(gdjs.Untitled_32sceneCode.GDBulletsObjects1[i].getString() + ("abs(1)"));
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletsObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWall"), gdjs.Untitled_32sceneCode.GDBlueWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWall2"), gdjs.Untitled_32sceneCode.GDBlueWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWall2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWall2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWall2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWallObjects) >= 32;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWall2Objects) >= 32;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12842604);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullets"), gdjs.Untitled_32sceneCode.GDBulletsObjects1);
gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects, (( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1[i].setZOrder(25);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1[i].addPolarForce((( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getAngle()), 450, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletsObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedWall"), gdjs.Untitled_32sceneCode.GDRedWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedWall2"), gdjs.Untitled_32sceneCode.GDRedWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDRedWall2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWall2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWall2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWallObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWall2Objects) == 0;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12961972);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullets"), gdjs.Untitled_32sceneCode.GDBulletsObjects1);
gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallBulletObjects1Objects, (( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1[i].setZOrder(25);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1[i].addPolarForce((( gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[0].getAngle()), 450, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletsObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Untitled_32sceneCode.GDBlackWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWallBullet"), gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Untitled_32sceneCode.GDBlackWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWallBullet"), gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWall2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWall2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWall2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWall"), gdjs.Untitled_32sceneCode.GDBlueWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWall2"), gdjs.Untitled_32sceneCode.GDBlueWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWall2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWall2Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall"), gdjs.Untitled_32sceneCode.GDRedWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall2"), gdjs.Untitled_32sceneCode.GDRedWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWall2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Untitled_32sceneCode.GDBlackWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Untitled_32sceneCode.GDBlackWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDAlienYellowSuitObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWall2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall"), gdjs.Untitled_32sceneCode.GDRedWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall2"), gdjs.Untitled_32sceneCode.GDRedWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWall2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWall2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Untitled_32sceneCode.GDBlackWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Untitled_32sceneCode.GDBlackWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlueWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWall2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Untitled_32sceneCode.GDBlackWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1 */
{}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Untitled_32sceneCode.GDBlackWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDRedWallBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBlackWall2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1 */
{}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Untitled_32sceneCode.GDCursorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCursorObjects1[i].getY() > 270 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCursorObjects1[k] = gdjs.Untitled_32sceneCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCursorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCursorObjects1[i].getY() < 435 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCursorObjects1[k] = gdjs.Untitled_32sceneCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCursorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCursorObjects1 */
{gdjs.evtsExt__WithThreeJS__Rotate3DCameraLikeHead.func(runtimeScene, "=", (( gdjs.Untitled_32sceneCode.GDCursorObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCursorObjects1[0].getPointY("")) * -(1), (( gdjs.Untitled_32sceneCode.GDCursorObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCursorObjects1[0].getPointX("")) * -(1), 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Untitled_32sceneCode.GDCursorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCursorObjects1[i].getY() <= 270 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCursorObjects1[k] = gdjs.Untitled_32sceneCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCursorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCursorObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCursorObjects1[i].setY(270);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Untitled_32sceneCode.GDCursorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCursorObjects1[i].getY() >= 435 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCursorObjects1[k] = gdjs.Untitled_32sceneCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCursorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCursorObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCursorObjects1[i].setY(435);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDRedWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDBlackWall2Objects) == 0;
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Untitled_32sceneCode.GDWinObjects1);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWinObjects1[i].hide(false);
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDGreenBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreenBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueWallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueWallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueWall2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueWall2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueWallBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedWallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedWallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedWall2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedWall2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedWallBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedWallBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlackWallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlackWallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlackWall2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlackWall2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlackWallBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCursorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCursorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCrossHairObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCrossHairObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAlienYellowSuitObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCalicoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCalicoObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletsUsedObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletsUsedObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTimeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTimeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTimeUsedObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTimeUsedObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLoseObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLoseObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
