gdjs.StartCode = {};
gdjs.StartCode.GDStartObjects1_1final = [];

gdjs.StartCode.GDBoxObjects1= [];
gdjs.StartCode.GDBoxObjects2= [];
gdjs.StartCode.GDNewSpriteObjects1= [];
gdjs.StartCode.GDNewSpriteObjects2= [];
gdjs.StartCode.GDStartObjects1= [];
gdjs.StartCode.GDStartObjects2= [];


gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDBoxObjects1Objects = Hashtable.newFrom({"Box": gdjs.StartCode.GDBoxObjects1});
gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDStartObjects2Objects = Hashtable.newFrom({"Start": gdjs.StartCode.GDStartObjects2});
gdjs.StartCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.input.showCursor(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.StartCode.GDBoxObjects1);
gdjs.StartCode.GDStartObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDBoxObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.StartCode.GDStartObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.StartCode.GDStartObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.StartCode.mapOfGDgdjs_46StartCode_46GDStartObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.StartCode.GDStartObjects2.length; j < jLen ; ++j) {
        if ( gdjs.StartCode.GDStartObjects1_1final.indexOf(gdjs.StartCode.GDStartObjects2[j]) === -1 )
            gdjs.StartCode.GDStartObjects1_1final.push(gdjs.StartCode.GDStartObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.StartCode.GDStartObjects1_1final, gdjs.StartCode.GDStartObjects1);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Game", false);
}}

}


};

gdjs.StartCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.StartCode.GDBoxObjects1.length = 0;
gdjs.StartCode.GDBoxObjects2.length = 0;
gdjs.StartCode.GDNewSpriteObjects1.length = 0;
gdjs.StartCode.GDNewSpriteObjects2.length = 0;
gdjs.StartCode.GDStartObjects1.length = 0;
gdjs.StartCode.GDStartObjects2.length = 0;

gdjs.StartCode.eventsList0(runtimeScene);

return;

}

gdjs['StartCode'] = gdjs.StartCode;
