gdjs.Main_32GameCode = {};
gdjs.Main_32GameCode.GDGreenBackgroundObjects1= [];
gdjs.Main_32GameCode.GDGreenBackgroundObjects2= [];
gdjs.Main_32GameCode.GDBlueWallObjects1= [];
gdjs.Main_32GameCode.GDBlueWallObjects2= [];
gdjs.Main_32GameCode.GDBlueWall2Objects1= [];
gdjs.Main_32GameCode.GDBlueWall2Objects2= [];
gdjs.Main_32GameCode.GDBlueWallBulletObjects1= [];
gdjs.Main_32GameCode.GDBlueWallBulletObjects2= [];
gdjs.Main_32GameCode.GDRedWallObjects1= [];
gdjs.Main_32GameCode.GDRedWallObjects2= [];
gdjs.Main_32GameCode.GDRedWall2Objects1= [];
gdjs.Main_32GameCode.GDRedWall2Objects2= [];
gdjs.Main_32GameCode.GDRedWallBulletObjects1= [];
gdjs.Main_32GameCode.GDRedWallBulletObjects2= [];
gdjs.Main_32GameCode.GDBlackWallObjects1= [];
gdjs.Main_32GameCode.GDBlackWallObjects2= [];
gdjs.Main_32GameCode.GDBlackWall2Objects1= [];
gdjs.Main_32GameCode.GDBlackWall2Objects2= [];
gdjs.Main_32GameCode.GDBlackWallBulletObjects1= [];
gdjs.Main_32GameCode.GDBlackWallBulletObjects2= [];
gdjs.Main_32GameCode.GDCursorObjects1= [];
gdjs.Main_32GameCode.GDCursorObjects2= [];
gdjs.Main_32GameCode.GDCrossHairObjects1= [];
gdjs.Main_32GameCode.GDCrossHairObjects2= [];
gdjs.Main_32GameCode.GDAlienYellowSuitObjects1= [];
gdjs.Main_32GameCode.GDAlienYellowSuitObjects2= [];
gdjs.Main_32GameCode.GDCalicoObjects1= [];
gdjs.Main_32GameCode.GDCalicoObjects2= [];
gdjs.Main_32GameCode.GDBulletsObjects1= [];
gdjs.Main_32GameCode.GDBulletsObjects2= [];
gdjs.Main_32GameCode.GDBulletsUsedObjects1= [];
gdjs.Main_32GameCode.GDBulletsUsedObjects2= [];
gdjs.Main_32GameCode.GDTimeObjects1= [];
gdjs.Main_32GameCode.GDTimeObjects2= [];
gdjs.Main_32GameCode.GDTimeUsedObjects1= [];
gdjs.Main_32GameCode.GDTimeUsedObjects2= [];
gdjs.Main_32GameCode.GDWinObjects1= [];
gdjs.Main_32GameCode.GDWinObjects2= [];
gdjs.Main_32GameCode.GDLoseObjects1= [];
gdjs.Main_32GameCode.GDLoseObjects2= [];
gdjs.Main_32GameCode.GDRestartObjects1= [];
gdjs.Main_32GameCode.GDRestartObjects2= [];
gdjs.Main_32GameCode.GDrestartObjects1= [];
gdjs.Main_32GameCode.GDrestartObjects2= [];


gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallObjects1Objects = Hashtable.newFrom({"BlueWall": gdjs.Main_32GameCode.GDBlueWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWall2Objects1Objects = Hashtable.newFrom({"BlueWall2": gdjs.Main_32GameCode.GDBlueWall2Objects1});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlackWallObjects = Hashtable.newFrom({"BlackWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlackWall2Objects = Hashtable.newFrom({"BlackWall2": []});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Main_32GameCode.GDRedWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Main_32GameCode.GDRedWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Main_32GameCode.GDRedWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Main_32GameCode.GDRedWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Main_32GameCode.GDRedWall2Objects1});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallBulletObjects1Objects = Hashtable.newFrom({"BlackWallBullet": gdjs.Main_32GameCode.GDBlackWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallBulletObjects1Objects = Hashtable.newFrom({"BlackWallBullet": gdjs.Main_32GameCode.GDBlackWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallBulletObjects1Objects = Hashtable.newFrom({"BlackWallBullet": gdjs.Main_32GameCode.GDBlackWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallObjects1Objects = Hashtable.newFrom({"BlueWall": gdjs.Main_32GameCode.GDBlueWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallObjects1Objects = Hashtable.newFrom({"BlueWall": gdjs.Main_32GameCode.GDBlueWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWall2Objects1Objects = Hashtable.newFrom({"BlueWall2": gdjs.Main_32GameCode.GDBlueWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWall2Objects1Objects = Hashtable.newFrom({"BlueWall2": gdjs.Main_32GameCode.GDBlueWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Main_32GameCode.GDRedWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Main_32GameCode.GDRedWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Main_32GameCode.GDRedWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Main_32GameCode.GDRedWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Main_32GameCode.GDRedWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects = Hashtable.newFrom({"RedWall": gdjs.Main_32GameCode.GDRedWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Main_32GameCode.GDRedWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects = Hashtable.newFrom({"RedWall2": gdjs.Main_32GameCode.GDRedWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Main_32GameCode.GDRedWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects = Hashtable.newFrom({"BlackWall": gdjs.Main_32GameCode.GDBlackWallObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Main_32GameCode.GDRedWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects = Hashtable.newFrom({"BlackWall2": gdjs.Main_32GameCode.GDBlackWall2Objects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects = Hashtable.newFrom({"BlueWallBullet": gdjs.Main_32GameCode.GDBlueWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects = Hashtable.newFrom({"RedWallBullet": gdjs.Main_32GameCode.GDRedWallBulletObjects1});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects = Hashtable.newFrom({"AlienYellowSuit": gdjs.Main_32GameCode.GDAlienYellowSuitObjects1});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects = Hashtable.newFrom({"BlueWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects = Hashtable.newFrom({"BlueWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects = Hashtable.newFrom({"RedWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects = Hashtable.newFrom({"RedWall2": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlackWallObjects = Hashtable.newFrom({"BlackWall": []});
gdjs.Main_32GameCode.mapOfEmptyGDBlackWall2Objects = Hashtable.newFrom({"BlackWall2": []});
gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.Main_32GameCode.GDRestartObjects1});
gdjs.Main_32GameCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Lose"), gdjs.Main_32GameCode.GDLoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Main_32GameCode.GDWinObjects1);
{gdjs.evtsExt__WithThreeJS__Create3DScene.func(runtimeScene, 50, "153;150;189", "", "", 1, 1000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{for(var i = 0, len = gdjs.Main_32GameCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDWinObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDLoseObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDLoseObjects1[i].hide();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "game-start-6104.mp3", false, 100, 1);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "lose");
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Time"), gdjs.Main_32GameCode.GDTimeObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDTimeObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDTimeObjects1[i].setString(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer"))));
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].setAngle((( gdjs.Main_32GameCode.GDCursorObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDCursorObjects1[0].getPointX("")) - 90);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].getAngle()), 150, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].getAngle()) - 90, 150, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].getAngle()) + 180, 150, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].addPolarForce((gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].getAngle()) + 90, 150, 0);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects) >= 24;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects) >= 24;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13562956);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullets"), gdjs.Main_32GameCode.GDBulletsObjects1);
gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, (( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getPointX("")), (( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].setZOrder(25);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].addPolarForce((( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getAngle()), 450, 1);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBulletsObjects1[i].setString(gdjs.Main_32GameCode.GDBulletsObjects1[i].getString() + ("abs(1)"));
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBulletsObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "9mm-pistol-shoot-short-reverb-7152.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWall"), gdjs.Main_32GameCode.GDBlueWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlueWallObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWall2"), gdjs.Main_32GameCode.GDBlueWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlueWall2Objects1 */
/* Reuse gdjs.Main_32GameCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWall2Objects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWall2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13571444);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "9mm-pistol-load-and-chamber-98830.mp3", false, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlackWallObjects) >= 32;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlackWall2Objects) >= 32;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13574652);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullets"), gdjs.Main_32GameCode.GDBulletsObjects1);
gdjs.Main_32GameCode.GDRedWallBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects, (( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getPointX("")), (( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].setZOrder(25);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].addPolarForce((( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getAngle()), 450, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBulletsObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "9mm-pistol-shoot-short-reverb-7152.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedWall"), gdjs.Main_32GameCode.GDRedWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Main_32GameCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDRedWallObjects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedWall2"), gdjs.Main_32GameCode.GDRedWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Main_32GameCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDRedWall2Objects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWall2Objects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWall2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13581300);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "9mm-pistol-load-and-chamber-98830.mp3", false, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects) == 0;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13584124);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bullets"), gdjs.Main_32GameCode.GDBulletsObjects1);
gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallBulletObjects1Objects, (( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getPointX("")), (( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallBulletObjects1[i].setZOrder(25);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallBulletObjects1[i].addPolarForce((( gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[0].getAngle()), 450, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBulletsObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBulletsObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "9mm-pistol-shoot-short-reverb-7152.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Main_32GameCode.GDBlackWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWallBullet"), gdjs.Main_32GameCode.GDBlackWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlackWallObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlackWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Main_32GameCode.GDBlackWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWallBullet"), gdjs.Main_32GameCode.GDBlackWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlackWall2Objects1 */
/* Reuse gdjs.Main_32GameCode.GDBlackWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWall2Objects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWall2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallBulletObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlackWallBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWall"), gdjs.Main_32GameCode.GDBlueWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlueWallObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWall2"), gdjs.Main_32GameCode.GDBlueWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlueWall2Objects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWall2Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall"), gdjs.Main_32GameCode.GDRedWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWallObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall2"), gdjs.Main_32GameCode.GDRedWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWall2Objects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Main_32GameCode.GDBlackWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlackWallObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Main_32GameCode.GDBlackWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDAlienYellowSuitObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlackWall2Objects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDAlienYellowSuitObjects1[i].separateFromObjectsList(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall"), gdjs.Main_32GameCode.GDRedWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlueWallBulletObjects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWallObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWall2"), gdjs.Main_32GameCode.GDRedWall2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlueWallBulletObjects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWall2Objects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWall2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Main_32GameCode.GDBlackWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlackWallObjects1 */
/* Reuse gdjs.Main_32GameCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Main_32GameCode.GDBlackWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlackWall2Objects1 */
/* Reuse gdjs.Main_32GameCode.GDBlueWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall"), gdjs.Main_32GameCode.GDBlackWallObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Main_32GameCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlackWallObjects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWallObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackWall2"), gdjs.Main_32GameCode.GDBlackWall2Objects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Main_32GameCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDBlackWall2Objects1 */
/* Reuse gdjs.Main_32GameCode.GDRedWallBulletObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlackWall2Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueWallBullet"), gdjs.Main_32GameCode.GDBlueWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length;i<l;++i) {
    if ( gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i].getBehavior("Bounce").BounceCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32GameCode.GDBlueWallBulletObjects1[k] = gdjs.Main_32GameCode.GDBlueWallBulletObjects1[i];
        ++k;
    }
}
gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDBlueWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, false, runtimeScene, false);
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Lose"), gdjs.Main_32GameCode.GDLoseObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDLoseObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDLoseObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "videogame-death-sound-43894.mp3", true, 100, 1);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "lose");
}{gdjs.evtTools.input.showCursor(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AlienYellowSuit"), gdjs.Main_32GameCode.GDAlienYellowSuitObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedWallBullet"), gdjs.Main_32GameCode.GDRedWallBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32GameCode.GDRedWallBulletObjects1.length;i<l;++i) {
    if ( gdjs.Main_32GameCode.GDRedWallBulletObjects1[i].getBehavior("Bounce").BounceCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32GameCode.GDRedWallBulletObjects1[k] = gdjs.Main_32GameCode.GDRedWallBulletObjects1[i];
        ++k;
    }
}
gdjs.Main_32GameCode.GDRedWallBulletObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRedWallBulletObjects1Objects, gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDAlienYellowSuitObjects1Objects, false, runtimeScene, false);
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Lose"), gdjs.Main_32GameCode.GDLoseObjects1);
{for(var i = 0, len = gdjs.Main_32GameCode.GDLoseObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDLoseObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "videogame-death-sound-43894.mp3", true, 100, 1);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "lose");
}{gdjs.evtTools.input.showCursor(runtimeScene);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32GameCode.GDCursorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32GameCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Main_32GameCode.GDCursorObjects1[i].getY() > 270 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32GameCode.GDCursorObjects1[k] = gdjs.Main_32GameCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Main_32GameCode.GDCursorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32GameCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Main_32GameCode.GDCursorObjects1[i].getY() < 435 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32GameCode.GDCursorObjects1[k] = gdjs.Main_32GameCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Main_32GameCode.GDCursorObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDCursorObjects1 */
{gdjs.evtsExt__WithThreeJS__Rotate3DCameraLikeHead.func(runtimeScene, "=", (( gdjs.Main_32GameCode.GDCursorObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDCursorObjects1[0].getPointY("")) * -(1), (( gdjs.Main_32GameCode.GDCursorObjects1.length === 0 ) ? 0 :gdjs.Main_32GameCode.GDCursorObjects1[0].getPointX("")) * -(1), 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32GameCode.GDCursorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32GameCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Main_32GameCode.GDCursorObjects1[i].getY() <= 270 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32GameCode.GDCursorObjects1[k] = gdjs.Main_32GameCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Main_32GameCode.GDCursorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDCursorObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDCursorObjects1[i].setY(270);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.Main_32GameCode.GDCursorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32GameCode.GDCursorObjects1.length;i<l;++i) {
    if ( gdjs.Main_32GameCode.GDCursorObjects1[i].getY() >= 435 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32GameCode.GDCursorObjects1[k] = gdjs.Main_32GameCode.GDCursorObjects1[i];
        ++k;
    }
}
gdjs.Main_32GameCode.GDCursorObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32GameCode.GDCursorObjects1 */
{for(var i = 0, len = gdjs.Main_32GameCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDCursorObjects1[i].setY(435);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlueWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDRedWall2Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlackWallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32GameCode.mapOfEmptyGDBlackWall2Objects) == 0;
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Main_32GameCode.GDWinObjects1);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{for(var i = 0, len = gdjs.Main_32GameCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Main_32GameCode.GDWinObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "level-win-6416.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Main_32GameCode.GDRestartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32GameCode.mapOfGDgdjs_46Main_9532GameCode_46GDRestartObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13719620);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start", false);
}}

}


};

gdjs.Main_32GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32GameCode.GDGreenBackgroundObjects1.length = 0;
gdjs.Main_32GameCode.GDGreenBackgroundObjects2.length = 0;
gdjs.Main_32GameCode.GDBlueWallObjects1.length = 0;
gdjs.Main_32GameCode.GDBlueWallObjects2.length = 0;
gdjs.Main_32GameCode.GDBlueWall2Objects1.length = 0;
gdjs.Main_32GameCode.GDBlueWall2Objects2.length = 0;
gdjs.Main_32GameCode.GDBlueWallBulletObjects1.length = 0;
gdjs.Main_32GameCode.GDBlueWallBulletObjects2.length = 0;
gdjs.Main_32GameCode.GDRedWallObjects1.length = 0;
gdjs.Main_32GameCode.GDRedWallObjects2.length = 0;
gdjs.Main_32GameCode.GDRedWall2Objects1.length = 0;
gdjs.Main_32GameCode.GDRedWall2Objects2.length = 0;
gdjs.Main_32GameCode.GDRedWallBulletObjects1.length = 0;
gdjs.Main_32GameCode.GDRedWallBulletObjects2.length = 0;
gdjs.Main_32GameCode.GDBlackWallObjects1.length = 0;
gdjs.Main_32GameCode.GDBlackWallObjects2.length = 0;
gdjs.Main_32GameCode.GDBlackWall2Objects1.length = 0;
gdjs.Main_32GameCode.GDBlackWall2Objects2.length = 0;
gdjs.Main_32GameCode.GDBlackWallBulletObjects1.length = 0;
gdjs.Main_32GameCode.GDBlackWallBulletObjects2.length = 0;
gdjs.Main_32GameCode.GDCursorObjects1.length = 0;
gdjs.Main_32GameCode.GDCursorObjects2.length = 0;
gdjs.Main_32GameCode.GDCrossHairObjects1.length = 0;
gdjs.Main_32GameCode.GDCrossHairObjects2.length = 0;
gdjs.Main_32GameCode.GDAlienYellowSuitObjects1.length = 0;
gdjs.Main_32GameCode.GDAlienYellowSuitObjects2.length = 0;
gdjs.Main_32GameCode.GDCalicoObjects1.length = 0;
gdjs.Main_32GameCode.GDCalicoObjects2.length = 0;
gdjs.Main_32GameCode.GDBulletsObjects1.length = 0;
gdjs.Main_32GameCode.GDBulletsObjects2.length = 0;
gdjs.Main_32GameCode.GDBulletsUsedObjects1.length = 0;
gdjs.Main_32GameCode.GDBulletsUsedObjects2.length = 0;
gdjs.Main_32GameCode.GDTimeObjects1.length = 0;
gdjs.Main_32GameCode.GDTimeObjects2.length = 0;
gdjs.Main_32GameCode.GDTimeUsedObjects1.length = 0;
gdjs.Main_32GameCode.GDTimeUsedObjects2.length = 0;
gdjs.Main_32GameCode.GDWinObjects1.length = 0;
gdjs.Main_32GameCode.GDWinObjects2.length = 0;
gdjs.Main_32GameCode.GDLoseObjects1.length = 0;
gdjs.Main_32GameCode.GDLoseObjects2.length = 0;
gdjs.Main_32GameCode.GDRestartObjects1.length = 0;
gdjs.Main_32GameCode.GDRestartObjects2.length = 0;
gdjs.Main_32GameCode.GDrestartObjects1.length = 0;
gdjs.Main_32GameCode.GDrestartObjects2.length = 0;

gdjs.Main_32GameCode.eventsList0(runtimeScene);

return;

}

gdjs['Main_32GameCode'] = gdjs.Main_32GameCode;
